export const coinIdData = {
  api_id: 'bitcoin',
};
