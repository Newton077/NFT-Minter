import CreateNFT from '@/components/create-nft/create-nft';

export default function CreateNFTPageModern() {
  return <CreateNFT />;
}
