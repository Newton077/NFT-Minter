import ModernScreen from '@/components/screens/modern-screen';

export default function IndexPageModern() {
  return <ModernScreen />;
}
