import AuthorProfilePage from '@/app/shared/profile';

export default function AuthorProfilePageModern() {
  return <AuthorProfilePage />;
}
