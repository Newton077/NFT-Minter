import VotePage from '@/app/shared/vote';

export default function VotePageModern() {
  return <VotePage />;
}
