import NotificationPage from '@/app/shared/notifications';

export default function NotificationPageModern() {
  return <NotificationPage />;
}
