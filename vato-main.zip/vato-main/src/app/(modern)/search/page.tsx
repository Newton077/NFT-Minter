import Search from '@/components/search/search';

export default function SearchPageModern() {
  return <Search />;
}
