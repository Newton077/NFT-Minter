import LiveDemo from '@/app/shared/live-pricing';

export default function LiveDemoModern() {
  return <LiveDemo />;
}
