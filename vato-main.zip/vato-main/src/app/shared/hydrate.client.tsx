'use client';

export { hydrate } from '@tanstack/react-query';
