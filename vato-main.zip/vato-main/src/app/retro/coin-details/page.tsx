import CoinSinglePrice from '@/app/shared/coin-details';

export default function SinglePriceRetro() {
  return <CoinSinglePrice />;
}
