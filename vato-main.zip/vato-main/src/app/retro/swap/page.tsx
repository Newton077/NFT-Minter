import SwapPage from '@/app/shared/swap';

export default function SwapPageRetro() {
  return <SwapPage />;
}
