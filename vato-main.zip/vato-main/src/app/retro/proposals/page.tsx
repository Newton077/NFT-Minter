import ProposalsPage from '@/app/shared/proposals';

export default function ProposalsPageRetro() {
  return <ProposalsPage />;
}
