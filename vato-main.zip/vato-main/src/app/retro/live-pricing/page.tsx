import LiveDemo from '@/app/shared/live-pricing';

export default function LiveDemoRetro() {
  return <LiveDemo />;
}
