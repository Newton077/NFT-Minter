import RetroSearch from '@/components/search/retro-search';

export default function SearchPageModern() {
  return <RetroSearch />;
}
