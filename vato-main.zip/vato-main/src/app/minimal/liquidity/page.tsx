import LiquidityPage from '@/app/shared/liquidity';

export default function LiquidityPageMinimal() {
  return <LiquidityPage />;
}
