import AuthorProfilePage from '@/app/shared/profile';

export default function AuthorProfilePageMinimal() {
  return <AuthorProfilePage />;
}
