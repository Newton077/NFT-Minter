import FarmsPage from '@/components/farms/farms';

export default function FarmsPageMinimal() {
  return <FarmsPage />;
}
