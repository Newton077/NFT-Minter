import Search from '@/components/search/search';

export default function SearchPageMinimal() {
  return <Search />;
}
