import VotePage from '@/app/shared/vote';

export default function VotePageMinimal() {
  return <VotePage />;
}
