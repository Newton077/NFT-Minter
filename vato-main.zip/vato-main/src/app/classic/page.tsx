import ClassicScreen from '@/components/screens/classic-screen';

export default function IndexPageClassic() {
  return <ClassicScreen />;
}
