import CoinSinglePrice from '@/app/shared/coin-details';

export default function SinglePriceClassic() {
  return <CoinSinglePrice />;
}
