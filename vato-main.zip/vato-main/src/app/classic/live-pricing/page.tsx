import LiveDemo from '@/app/shared/live-pricing';

export default function LiveDemoClassic() {
  return <LiveDemo />;
}
