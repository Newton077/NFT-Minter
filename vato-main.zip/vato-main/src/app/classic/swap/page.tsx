import SwapPage from '@/app/shared/swap';

export default function SwapPageClassic() {
  return <SwapPage />;
}
