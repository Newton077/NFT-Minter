import LiquidityPositionPage from '@/app/shared/liquidity-position';

export default function LiquidityPositionPageClassic() {
  return <LiquidityPositionPage />;
}
