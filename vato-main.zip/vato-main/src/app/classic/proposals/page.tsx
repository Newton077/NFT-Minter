import ProposalsPage from '@/app/shared/proposals';

export default function ProposalsPageClassic() {
  return <ProposalsPage />;
}
