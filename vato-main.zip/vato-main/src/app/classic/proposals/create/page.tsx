import CreateProposalsPage from '@/app/shared/create-proposals';

export default function CreateProposalsPageClassic() {
  return <CreateProposalsPage />;
}
